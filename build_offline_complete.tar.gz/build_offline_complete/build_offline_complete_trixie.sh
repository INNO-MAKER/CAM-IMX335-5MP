#!/bin/bash
# IMX335 Offline Build and Installation Script
# System: Debian Trixie (For Bookworm, use install_bookworm.sh)
# Hardware: Raspberry Pi 5
# Features: All source code is offline, no network connection required
# Function: One-click dependency installation, compile libcamera + rpicam-apps, support IMX335

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info() { echo -e "${GREEN}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "========================================="
echo "IMX335 Offline Build Script [Trixie]"
echo "========================================="
echo ""

# Check root
if [ "$EUID" -ne 0 ]; then
    error "Please run as root (use sudo)"
fi

# =============================================================================
# Step 1: Install dependencies
# =============================================================================
info "Step 1/5: Installing build dependencies..."

# Trixie compatible package names
apt-get update
apt-get install -y \
    build-essential meson ninja-build pkg-config cmake \
    python3-pip python3-jinja2 python3-ply python3-yaml \
    libdrm-dev libexif-dev libjpeg-dev libtiff5-dev \
    libboost-dev libqt5opengl5-dev libvulkan-dev libpng-dev \
    libglib2.0-dev libgstreamer-plugins-base1.0-dev \
    pybind11-dev libgnutls28-dev openssl \
    qtbase5-dev libqt5core5a libqt5gui5 libqt5widgets5 \
    libboost-program-options-dev libepoxy-dev \
    libavdevice-dev libavcodec-dev

info "Dependencies installed"

# =============================================================================
# Step 2: Check offline source code
# =============================================================================
info "Step 2/5: Checking offline source code..."

LIBCAMERA_SRC="$SCRIPT_DIR/libcamera"
RPICAM_SRC="$SCRIPT_DIR/rpicam-apps"
CAM_HELPER_335="$SCRIPT_DIR/cam_helper_imx335.cpp"

[ ! -d "$LIBCAMERA_SRC" ] && error "libcamera source not found: $LIBCAMERA_SRC"
[ ! -d "$RPICAM_SRC" ] && error "rpicam-apps source not found: $RPICAM_SRC"
[ ! -f "$CAM_HELPER_335" ] && warn "cam_helper_imx335.cpp not found"

info "Offline source code check complete"

# =============================================================================
# Step 3: Build and install libcamera (with IMX335 support)
# =============================================================================
info "Step 3/5: Building and installing libcamera..."

cd "$LIBCAMERA_SRC"

# Clean old build
[ -d "build" ] && rm -rf build

# Add IMX335 cam_helper files
CAM_HELPER_DIR="$LIBCAMERA_SRC/src/ipa/rpi/cam_helper"
MESON_FILE="$CAM_HELPER_DIR/meson.build"

if [ -f "$CAM_HELPER_335" ]; then
    cp "$CAM_HELPER_335" "$CAM_HELPER_DIR/"
    # Add to meson.build (add imx335 after imx296)
    if ! grep -q "cam_helper_imx335.cpp" "$MESON_FILE"; then
        sed -i "s/'cam_helper_imx296.cpp',/'cam_helper_imx296.cpp',\n    'cam_helper_imx335.cpp',/" "$MESON_FILE"
        info "Added cam_helper_imx335.cpp"
    fi
fi

# Configure and build
info "Configuring libcamera (meson)..."
meson setup build \
    --buildtype=release \
    -Dcam=disabled \
    -Dlc-compliance=disabled \
    -Dqcam=disabled \
    -Dtest=false \
    -Dv4l2=true \
    -Dpipelines=rpi/vc4,rpi/pisp \
    -Dipas=rpi/vc4,rpi/pisp \
    -Dgstreamer=enabled \
    -Dpycamera=enabled

info "Building libcamera (ninja)..."
ninja -C build

info "Installing libcamera..."
ninja -C build install
ldconfig

info "libcamera installation complete"

# =============================================================================
# Step 4: Build and install rpicam-apps
# =============================================================================
info "Step 4/5: Building and installing rpicam-apps..."

cd "$RPICAM_SRC"

# Clean old build
[ -d "build" ] && rm -rf build

info "Configuring rpicam-apps (meson)..."
meson setup build \
    --buildtype=release \
    -Denable_libav=enabled \
    -Denable_drm=enabled \
    -Denable_egl=enabled \
    -Denable_qt=enabled \
    -Denable_opencv=disabled \
    -Denable_tflite=disabled

info "Building rpicam-apps (ninja)..."
ninja -C build

info "Installing rpicam-apps..."
ninja -C build install
ldconfig

info "rpicam-apps installation complete"

# =============================================================================
# Step 5: Verify installation
# =============================================================================
info "Step 5/5: Verifying installation..."

echo ""
echo "========================================="
echo "Installation Complete!"
echo "========================================="
echo ""
echo "Detected cameras:"
rpicam-hello --list-cameras 2>/dev/null || echo "Please connect camera and reboot to test"
echo ""
echo "Available commands:"
echo "  rpicam-hello --list-cameras  # List cameras"
echo "  rpicam-still -o test.jpg      # Capture still image"
echo "  rpicam-vid -t 5000 -o test.h264  # Record video"
echo ""
echo "Note: If camera is not detected, please reboot and try again"
echo ""
