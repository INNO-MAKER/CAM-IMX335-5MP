#!/bin/bash
# imx335 bundle installer — copies binaries into place.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
TS="$(date +%Y%m%d-%H%M%S)"
HOST_REL="$(uname -r)"
LC_DIR="/usr/lib/aarch64-linux-gnu"

# Source manifest to determine bundle type
if [ -f "$ROOT/MANIFEST" ]; then
    . "$ROOT/MANIFEST"
else
    echo "WARN: MANIFEST not found, assuming IPA-only mode"
    only_ipa="1"
    bundle_type="ipaonly"
    base_driver="imx335.ko"
    base_driver_name="imx335"
fi

# Auto-detect which IPA .so is in this bundle (pi5=pisp, pi4=vc4)
IPA_PATH="$(ls "$ROOT"/libcamera/ipa_rpi_*.so 2>/dev/null | head -1)"
[ -n "$IPA_PATH" ] || { echo "ERROR: no ipa_rpi_*.so found in $ROOT/libcamera/"; exit 1; }
IPA_NAME="$(basename "$IPA_PATH")"
case "$IPA_NAME" in
    ipa_rpi_pisp.so) TUNE_SUBDIR="pisp" ;;
    ipa_rpi_vc4.so)  TUNE_SUBDIR="vc4" ;;
    *)               echo "ERROR: unexpected IPA name $IPA_NAME"; exit 1 ;;
esac

# Auto-detect tuning directory
TUNE_DIR=""
for _td in \
    /usr/local/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
    /usr/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
; do
    if [ -d "$_td" ]; then
        TUNE_DIR="$_td"
        break
    fi
done
[ -n "$TUNE_DIR" ] || TUNE_DIR="/usr/share/libcamera/ipa/rpi/${TUNE_SUBDIR}"

if [ "$only_ipa" = "1" ]; then
    echo "Installing IMX335 (IPA-ONLY mode, $IPA_NAME, kernel $HOST_REL)..."
else
    echo "Installing IMX335 (FULL mode, $IPA_NAME, kernel $HOST_REL, base driver: $base_driver)..."
fi

# ─── 1. kernel driver (FULL mode only) ──────────────────────────────────────
if [ "$only_ipa" = "0" ]; then
    DEST="/lib/modules/$HOST_REL/kernel/drivers/media/i2c"
    mkdir -p "$DEST"

    # Back up existing driver (handle both compressed and uncompressed)
    for EXT in .ko.xz .ko.zst .ko; do
        if [ -f "$DEST/${base_driver_name}${EXT}" ]; then
            mv "$DEST/${base_driver_name}${EXT}" "$DEST/${base_driver_name}${EXT}.bak.$TS"
            echo "  backed up existing ${base_driver_name}${EXT}"
        fi
    done

    cp "$ROOT/driver/$base_driver" "$DEST/"
    depmod -a
    echo "  driver installed ($base_driver)"

    # ─── 2. device tree overlay ─────────────────────────────────────────────
    cp "$ROOT/dts/imx335.dtbo" /boot/firmware/overlays/
    echo "  dtbo installed"
else
    # IPA-only mode: verify the system already has imx335 driver support
    HOST_HAS_DRIVER=0
    for DRV_NAME in imx335; do
        if modinfo "$DRV_NAME" 2>/dev/null | grep -qi imx335; then
            HOST_HAS_DRIVER=1
            echo "  host has imx335 kernel driver (mainline) — OK"
            break
        fi
    done
    if [ "$HOST_HAS_DRIVER" = "0" ]; then
        echo "  WARN: host system does NOT appear to have imx335 kernel driver loaded"
        echo "        Most RPi OS releases include it by default. If sensor doesn't"
        echo "        enumerate after install, check:"
        echo "          ls /lib/modules/\$(uname -r)/kernel/drivers/media/i2c/imx335*"
        echo "          ls /boot/firmware/overlays/imx335.dtbo"
    fi

    if [ ! -f /boot/firmware/overlays/imx335.dtbo ]; then
        echo "  WARN: /boot/firmware/overlays/imx335.dtbo not found"
        echo "        Update RPi firmware:  sudo rpi-update"
    fi
fi

# ─── 3. libcamera IPA ───────────────────────────────────────────────────────
# Auto-detect IPA install directory on target system
IPA_DEST=""
for _d in \
    /usr/local/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/local/lib/aarch64-linux-gnu/libcamera \
    /usr/lib/aarch64-linux-gnu/libcamera \
; do
    if [ -d "$_d" ] && ls "$_d"/ipa_rpi_*.so >/dev/null 2>&1; then
        IPA_DEST="$_d"
        break
    fi
done
[ -n "$IPA_DEST" ] || { echo "ERROR: cannot find libcamera IPA directory on target"; exit 1; }
[ -f "$IPA_DEST/$IPA_NAME" ] \
    && cp "$IPA_DEST/$IPA_NAME" "$IPA_DEST/${IPA_NAME}.bak.$TS"
cp "$ROOT/libcamera/$IPA_NAME" "$IPA_DEST/"
[ -f "$ROOT/libcamera/${IPA_NAME}.sign" ] \
    && cp "$ROOT/libcamera/${IPA_NAME}.sign" "$IPA_DEST/"
ldconfig
echo "  IPA installed to $IPA_DEST"

# ─── 4. tuning file ─────────────────────────────────────────────────────────
mkdir -p "$TUNE_DIR"
if [ -f "$ROOT/tuning/imx335.json" ]; then
    # Backup existing if it's a real file (not a symlink to base driver tune)
    if [ -f "$TUNE_DIR/imx335.json" ] && [ ! -L "$TUNE_DIR/imx335.json" ]; then
        cp "$TUNE_DIR/imx335.json" "$TUNE_DIR/imx335.json.bak.$TS"
    fi
    # If existing is a symlink, remove it before copying real file
    [ -L "$TUNE_DIR/imx335.json" ] && rm -f "$TUNE_DIR/imx335.json"
    cp "$ROOT/tuning/imx335.json" "$TUNE_DIR/"
    echo "  tuning file installed (imx335.json)"
else
    echo "  tuning file: not in bundle, system default will be used"
fi

# ─── 5. config.txt (FULL mode only) ─────────────────────────────────────────
if [ "$only_ipa" = "0" ]; then
    CFG=/boot/firmware/config.txt
    cp "$CFG" "$CFG.bak.$TS"
    sed -i '/^dtoverlay=imx335/d;/^camera_auto_detect/d' "$CFG"
    {
        echo ""
        echo "# IMX335 (from bundle, installed $TS)"
        echo "camera_auto_detect=0"
        echo "dtoverlay=imx335,cam0"
    } >> "$CFG"
    echo "  config.txt updated"
else
    # IPA-only: just check / hint
    CFG=/boot/firmware/config.txt
    if grep -q "^dtoverlay=imx335" "$CFG"; then
        echo "  config.txt: already has imx335 overlay — OK"
    else
        echo ""
        echo "  NOTE: config.txt does NOT have 'dtoverlay=imx335'"
        echo "        Add it manually for the camera to be enabled:"
        echo "          sudo nano /boot/firmware/config.txt"
        echo "        and add these lines:"
        echo "          camera_auto_detect=0"
        echo "          dtoverlay=imx335,cam0      # or cam1 depending on connector"
        echo ""
    fi
fi

echo ""
if [ "$only_ipa" = "1" ]; then
    echo "All done (IPA-only install)."
    echo "  If config.txt was already correct, no reboot needed for IPA changes."
    echo "  If config.txt was just edited, reboot:  sudo reboot"
else
    echo "All done. Reboot required:  sudo reboot"
fi
echo "Verify:  rpicam-hello --list-cameras"
