#!/bin/bash
# imx335 bundle uninstaller — restores backups.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
HOST_REL="$(uname -r)"
DEST="/lib/modules/$HOST_REL/kernel/drivers/media/i2c"

# Source manifest to determine mode
if [ -f "$ROOT/MANIFEST" ]; then
    . "$ROOT/MANIFEST"
else
    only_ipa="1"
fi

if grep -q "Raspberry Pi 5" /proc/device-tree/model 2>/dev/null; then
    TUNE_DIR="/usr/share/libcamera/ipa/rpi/pisp"
    IPA_NAME="ipa_rpi_pisp.so"
else
    TUNE_DIR="/usr/share/libcamera/ipa/rpi/vc4"
    IPA_NAME="ipa_rpi_vc4.so"
fi

# Auto-detect IPA install directory
IPA_DEST=""
for _d in \
    /usr/local/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/local/lib/aarch64-linux-gnu/libcamera \
    /usr/lib/aarch64-linux-gnu/libcamera \
; do
    if [ -d "$_d" ] && ls "$_d"/ipa_rpi_*.so >/dev/null 2>&1; then
        IPA_DEST="$_d"
        break
    fi
done

echo "=== IMX335 bundle uninstall ==="

# Restore IPA backup (most recent)
if [ -n "$IPA_DEST" ]; then
    LATEST_IPA_BAK="$(ls -t "$IPA_DEST/${IPA_NAME}.bak."* 2>/dev/null | head -1)"
    if [ -n "$LATEST_IPA_BAK" ]; then
        cp "$LATEST_IPA_BAK" "$IPA_DEST/$IPA_NAME"
        ldconfig
        echo "  restored IPA: $IPA_DEST/$IPA_NAME"
    fi
fi

# Restore tuning backup
LATEST_TUNE_BAK="$(ls -t "$TUNE_DIR/imx335.json.bak."* 2>/dev/null | head -1)"
if [ -n "$LATEST_TUNE_BAK" ]; then
    cp "$LATEST_TUNE_BAK" "$TUNE_DIR/imx335.json"
    echo "  restored tuning: $TUNE_DIR/imx335.json"
fi

# Full-mode-only steps
if [ "$only_ipa" = "0" ]; then
    # Restore driver backup
    LATEST_BAK="$(ls -t "$DEST/imx335.ko"*.bak.* 2>/dev/null | head -1)"
    if [ -n "$LATEST_BAK" ]; then
        ORIG="${LATEST_BAK%.bak.*}"
        cp "$LATEST_BAK" "$ORIG"
        echo "  restored driver: $ORIG"
        depmod -a
    fi

    # Restore config.txt backup
    LATEST_CFG="$(ls -t /boot/firmware/config.txt.bak.* 2>/dev/null | head -1)"
    if [ -n "$LATEST_CFG" ]; then
        cp "$LATEST_CFG" /boot/firmware/config.txt
        echo "  restored config.txt from $LATEST_CFG"
    fi
fi

echo ""
if [ "$only_ipa" = "1" ]; then
    echo "Uninstall done (IPA-only). No reboot required, but you may want to:  sudo systemctl restart anything using camera"
else
    echo "Uninstall done. Reboot required:  sudo reboot"
fi
