#!/bin/bash
# Auto-detect which IPA variant this host should have based on Pi model
if grep -q "Raspberry Pi 5" /proc/device-tree/model 2>/dev/null; then
    IPA_NAME="ipa_rpi_pisp.so"; TUNE_SUBDIR="pisp"
else
    IPA_NAME="ipa_rpi_vc4.so";  TUNE_SUBDIR="vc4"
fi

# Auto-detect IPA location
IPA=""
for _d in \
    /usr/local/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/lib/aarch64-linux-gnu/libcamera/ipa/rpi/${TUNE_SUBDIR} \
    /usr/local/lib/aarch64-linux-gnu/libcamera \
    /usr/lib/aarch64-linux-gnu/libcamera \
; do
    [ -f "$_d/$IPA_NAME" ] && IPA="$_d/$IPA_NAME" && break
done

# Auto-detect tuning location
T=""
for _td in \
    /usr/local/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
    /usr/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
; do
    [ -e "$_td/imx335.json" ] && T="$_td/imx335.json" && break
done

F=0

echo "=== IMX335 bundle verification ==="
echo ""

# IPA binary
if [ -n "$IPA" ] && [ -f "$IPA" ]; then
    echo "[PASS] $IPA"
    strings "$IPA" 2>/dev/null | grep -qi imx335 \
        && echo "[PASS] imx335 in $IPA_NAME" \
        || echo "[WARN] imx335 not in $IPA_NAME (OK if using fallback cam_helper)"
else
    echo "[FAIL] $IPA_NAME not found in any standard location"; F=1
fi

# Tuning
if [ -n "$T" ] && [ -e "$T" ]; then
    echo "[PASS] tuning $T"
    [ -L "$T" ] && echo "  NOTE: imx335.json is a symlink -> $(readlink "$T")"
else
    echo "[FAIL] imx335.json not found in any standard location"; F=1
fi

# Kernel driver
if modinfo imx335 2>/dev/null | grep -qi imx335; then
    echo "[PASS] kernel driver imx335 advertises imx335"
else
    echo "[WARN] imx335 driver not loaded (need 'sudo modprobe imx335' or reboot)"
fi

# Overlay
[ -f /boot/firmware/overlays/imx335.dtbo ] \
    && echo "[PASS] imx335.dtbo present" \
    || echo "[FAIL] imx335.dtbo missing"

# config.txt
grep -q "dtoverlay=imx335" /boot/firmware/config.txt 2>/dev/null \
    && echo "[PASS] config.txt has imx335 overlay" \
    || echo "[WARN] config.txt missing imx335 overlay entry"

echo ""
echo "--- camera enumeration ---"
rpicam-hello --list-cameras 2>&1 | head -30 || true

exit $F
