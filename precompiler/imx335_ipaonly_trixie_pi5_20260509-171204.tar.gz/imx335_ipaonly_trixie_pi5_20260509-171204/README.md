# IMX335 prebuilt bundle: imx335_ipaonly_trixie_pi5_20260509-171204

Bundle type: **IPA-only** (kernel driver and dtbo come from RPi OS)

## Sensor info

- Sony IMX335, STARVIS technology
- 1/2.8" format, 5MP (2592×1944)
- 2.0µm pixel pitch
- Color sensor, rolling shutter
- Mainstream surveillance/IP-camera sensor
- Driver supported upstream by mainline Linux (since v5.18)
- Raspberry Pi OS ships imx335 driver, dtbo, and tuning out of the box

## Build environment

- Model:    Raspberry Pi 5 Model B Rev 1.0
- OS:       debian trixie (13)
- Kernel:   6.12.75+rpt-rpi-2712
- libcamera: libcamera.so.0.7 / libcamera-base.so.0.7


Because this is an IPA-only bundle, **no kernel module is replaced**.
The IMX335 driver and dtbo from your existing Raspberry Pi OS install are
used. The bundle only updates the libcamera IPA `.so` and the imx335.json
tuning file. This means it works across kernel versions on the same OS.

## Install

    tar -xzf imx335_ipaonly_trixie_pi5_20260509-171204.tar.gz
    cd imx335_ipaonly_trixie_pi5_20260509-171204
    sudo ./scripts/install.sh
    # IPA-only: usually no reboot needed unless config.txt changed
    ./scripts/verify.sh

## Uninstall

    sudo ./scripts/uninstall.sh


## Notes

- IMX335 is a rolling shutter sensor. For high-speed motion or strobe
  applications, consider IMX296 (global shutter) instead.
- For best image quality you may want to tune `imx335.json` for your
  specific lens — the bundled tuning is a baseline.
- If the camera does not enumerate after install, check:
    rpicam-hello --list-cameras
    dmesg | grep imx335
    cat /boot/firmware/config.txt | grep imx335
